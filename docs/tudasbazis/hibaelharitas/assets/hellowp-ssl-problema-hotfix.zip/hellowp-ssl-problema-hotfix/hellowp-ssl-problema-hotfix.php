<?php

/**
* Plugin Name: SSL probléma Hotfix
* Plugin URI: https://hellowp.io
* Description: Megold egy pillanatnyi hibát, amit a Let’s Encrypt frissítése okoz elavult szervereken
* Version: 1.0
* Author: TooEarlyBird,LLC
* Author URI: https://hellowp.io
*/

add_filter('https_ssl_verify', '__return_false');
